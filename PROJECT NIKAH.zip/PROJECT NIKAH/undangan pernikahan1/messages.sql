-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2026 at 06:39 AM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.3.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wedding_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `pesan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `nama`, `alamat`, `pesan`, `created_at`) VALUES
(1, 'f', 'gggg', 'fgge', '2026-04-18 23:16:38'),
(2, 'eghjrhg', 'gshghjf', 'bdgshshs', '2026-04-18 23:21:22'),
(3, 'dapa', 'paseh', 'selamatttttt', '2026-04-19 03:34:48'),
(4, 'rijal', 'cimalaka', 'hore', '2026-04-19 04:12:01'),
(5, 'rijal', 'cimalaka', 'hore', '2026-04-19 04:12:35'),
(6, 'hrsghssfhsjf', 'shdghsjshjgffb', 'fdgk;shjsrt,ns;lhj', '2026-04-19 04:13:06'),
(7, 'kgjshdvlakdjvljvcx,mnx', 'egjktldfkfvnsdmfnbslkj', 'gfbmfnk;jgfivgrbmn,j', '2026-04-19 04:16:01'),
(8, 'kgjshdvlakdjvljvcx,mnx', 'egjktldfkfvnsdmfnbslkj', 'gfbmfnk;jgfivgrbmn,j', '2026-04-19 04:19:08'),
(9, 'kgjshdvlakdjvljvcx,mnx', 'egjktldfkfvnsdmfnbslkj', 'gfbmfnk;jgfivgrbmn,jfbg', '2026-04-19 04:19:18'),
(10, 'sgkjnetgs,mgn', 'etlsgnne,gmndf,.s', 'slkjgr,eng,emfgnr', '2026-04-19 04:25:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
