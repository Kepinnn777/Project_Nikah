<?php
include 'koneksi.php';

$nama   = $_POST['nama'];
$alamat = $_POST['alamat'];
$pesan  = $_POST['pesan'];

$query = "INSERT INTO messages (nama, alamat, pesan)
          VALUES ('$nama', '$alamat', '$pesan')";

if (mysqli_query($conn, $query)) {
    echo "success";
} else {
    echo "error";
}
?>