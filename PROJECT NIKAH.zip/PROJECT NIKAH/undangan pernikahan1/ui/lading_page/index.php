<?php
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wedding Invitation</title>

  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600&family=Great+Vibes&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="nav-container">
      <div class="logo">C & A</div>

      <div class="hamburger" id="hamburger">
        <span></span>
        <span></span>
        <span></span>
      </div>

      <ul class="nav-menu" id="nav-menu">
        <li><a href="#home">Home</a></li>
        <li><a href="#bride">Bride</a></li>
        <li><a href="#groom">Groom</a></li>
        <li><a href="#event">Event</a></li>
        <li><a href="#story">Story</a></li>
        <li><a href="#gallery">Gallery</a></li>
        <li><a href="#wishes">Wishes</a></li>
        <li><a href="#messages">Messages</a></li>
      </ul>
    </div>
  </nav>

  <!-- SECTION 1 -->
  <section id="home" class="section">
    <div class="card">
      <div class="title">WEDDING OF</div>
      <div class="names">Clara & Andri</div>
      <div class="date">March 12th, 2026</div>

      <div class="photo">
        <img src="../gambar/gambar1.jpeg">
      </div>

      <div class="desc">
        And among His signs is that He created for you mates from among yourselves so that you may find tranquility in
        them.
      </div>

      <div class="ayat">Surah Ar-Rum : 21</div>
    </div>

    <img src="../gambar/hiasan_bunga.png" class="bunga">
  </section>

  <!-- BRIDE -->
  <section id="bride" class="section section-bride">
    <div class="card">
      <div class="title-2">THE BRIDE</div>

      <div class="subtext">
        The pleasure of your company is requested<br>
        at the marriage of
      </div>

      <div class="photo-oval">
        <img src="../gambar/gambar2.jpeg">
      </div>

      <div class="bride-name">Dr. Clara Aurelie</div>

      <div class="parent">
        Second daughter of<br>
        Mr. Hengki &<br>
        Mrs. Imas
      </div>
    </div>
  </section>

  <!-- GROOM -->
  <section id="groom" class="section section-groom">
    <div class="card">
      <div class="title-2">THE GROOM</div>

      <div class="subtext">
        The pleasure of your company is requested<br>
        at the marriage of
      </div>

      <div class="photo-oval">
        <img src="../gambar/gambar3.jpeg">
      </div>

      <div class="groom-name">Andrian Agustian S.Pd</div>

      <div class="parent">
        First son of<br>
        Mr. Agus Setiawan &<br>
        Mrs. Mumun
      </div>
    </div>
  </section>

  <!-- EVENT -->
  <section id="event" class="section section-event">
    <div class="card event-card">

      <div class="event-block">
        <div class="event-title">Ceremony</div>
        <div class="event-text">
          Sunday, March 14th 2026<br>
          08.00 AM - finish<br>
          Asia Plaza Hall, Sumedang
        </div>
      </div>

      <div class="divider"><span></span></div>

      <div class="event-block">
        <div class="event-title">Reception</div>
        <div class="event-text">
          Sunday, March 14th 2026<br>
          08.00 PM - finish<br>
          Asia Plaza Hall, Sumedang
        </div>
      </div>

    </div>
  </section>

  <!-- STORY -->
  <section id="story" class="section section-story">

    <div class="story-content">
      <div class="story-title">Love Story</div>

      <div class="story-item">
        <div class="dot"></div>
        <div class="story-text">
          <strong>First Encounter</strong><br>
          It all began with a simple moment that was never planned.
          At first, we were just strangers, until time slowly brought us closer.
        </div>
      </div>

      <div class="story-item">
        <div class="dot"></div>
        <div class="story-text">
          <strong>Growing Closer</strong><br>
          As time passed, we began to understand each other more deeply.
          Together, we faced countless moments, laughter, and even tears.
        </div>
      </div>

      <div class="story-item">
        <div class="dot"></div>
        <div class="story-text">
          <strong>Commitment</strong><br>
          With confidence and love, we took the step forward.
          Through joy and sorrow, we promised to always stay together.
        </div>
      </div>

      <div class="story-item">
        <div class="dot"></div>
        <div class="story-text">
          <strong>Marriage</strong><br>
          With blessings and prayers, our hearts are finally united.
          Not just for today, but for a lifetime of togetherness.
        </div>
      </div>

    </div>

    <!-- bunga bawah -->
    <img src="../gambar/hiasan_bunga.png" class="bunga-kiri">
    <img src="../gambar/hiasan_bunga2.png" class="bunga-kanan">

  </section>

  <!-- GALLERY -->
  <!-- GALLERY -->
  <section id="gallery" class="section section-gallery">

    <!-- bunga atas -->
    <img src="../gambar/bunga_atas.png" class="bunga-top-left">
    <img src="../gambar/bunga_atas2.png" class="bunga-top-right">

    <div class="card">
      <div class="gallery-content">

        <div class="gallery-title">Our Memories</div>
        <div class="gallery-line"></div>

        <div class="gallery-grid">
          <img src="../gambar/gambar4 (1).jpeg">
          <img src="../gambar/gambar5.jpeg">
          <img src="../gambar/gambar6.jpeg">
          <img src="../gambar/gambar7.jpeg">
        </div>

      </div>
    </div>

  </section>


  <!-- WISHES -->
  <section id="wishes" class="section section-ucapan">

    <!-- bunga atas -->
    <img src="../gambar/bunga_atas.png" class="bunga-top-left">
    <img src="../gambar/bunga_atas2.png" class="bunga-top-right">

    <div class="ucapan-content">

      <div class="ucapan-title">Wishes</div>

      <form id="formPesan" class="form">
        <input type="text" name="nama" placeholder="Name" required>
        <input type="text" name="alamat" placeholder="Address" required>
        <textarea name="pesan" placeholder="Message" required></textarea>
        <button type="submit">Send</button>
      </form>

      <div class="gift-title">Gift</div>

      <div class="qr-box">
        <img src="../gambar/qr.jpeg">
      </div>

      <div class="thanks">Thank You</div>

    </div>

    <!-- bunga bawah -->
    <img src="../gambar/hiasan_bunga.png" class="bunga-bottom-left">
    <img src="../gambar/hiasan_bunga2.png" class="bunga-bottom-right">

  </section>

  <section id="messages" class="section section-comment">

    <!-- bunga atas -->
    <img src="../gambar/bunga_atas.png" class="bunga-top-left">
    <img src="../gambar/bunga_atas2.png" class="bunga-top-right">

    <div class="comment-content">
      <div class="comment-title">Messages</div>
      <div class="comment-scroll"></div>
    </div>

    </div>

    <!-- bunga bawah -->
    <img src="../gambar/hiasan_bunga.png" class="bunga-bottom-left">
    <img src="../gambar/hiasan_bunga2.png" class="bunga-bottom-right">

  </section>

  <footer class="footer">
  <div class="footer-container">

    <div class="footer-names">Clara & Andri</div>

    <div class="footer-text">
      Thank you for being part of our special day.<br>
      Your presence means everything to us.
    </div>

    <div class="footer-line"></div>

    <div class="footer-social">
      <a href="#">Instagram</a>
      <a href="#">WhatsApp</a>
      <a href="https://maps.app.goo.gl/VogkZ5nvGfkbXq7Z7  ">Maps</a>
    </div>

    <div class="footer-copy">
      © 2026 Clara & Andri Wedding. All Rights Reserved.
    </div>

  </div>
</footer>

  <!-- SCRIPT -->
  <script>
    // NAVBAR
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');

    hamburger.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });

    document.querySelectorAll('.nav-menu a').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
      });
    });


    // ANIMASI SCROLL
    const elements = document.querySelectorAll('.card, .story-item, .gallery-grid img, .ucapan-content');

    elements.forEach(el => {
      el.classList.add('animate');
    });

    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        }
      });
    }, {
      threshold: 0.2
    });

    elements.forEach(el => observer.observe(el));

    // KIRIM DATA
    document.getElementById("formPesan").addEventListener("submit", function (e) {
      e.preventDefault();

      const formData = new FormData(this);

      fetch("simpan_pesan.php", {
          method: "POST",
          body: formData
        })
        .then(res => res.text())
        .then(data => {
          console.log("Response:", data);

          if (data.trim() === "success") {
            alert("Pesan berhasil dikirim!");
            loadPesan();
            this.reset();
          } else {
            alert("Gagal kirim!");
          }
        });
    });


    // AMBIL DATA
    function loadPesan() {
      fetch("ambil_pesan.php")
        .then(res => res.json())
        .then(data => {

          const container = document.querySelector(".comment-scroll");
          container.innerHTML = "";

          if (data.length === 0) {
            container.innerHTML = "<p style='text-align:center'>Belum ada pesan</p>";
          }

          data.forEach(item => {
            container.innerHTML += `
        <div class="comment-item show">
          <img src="../gambar/profil.png" class="avatar">
           
          <div class="bubble">
            <div class="name">${item.nama}</div>
            <div class="message">${item.pesan}</div>
          </div>
        </div>
      `;
          });

        })
        .catch(err => {
          console.error("Error ambil data:", err);
        });
    }

    // LOAD AWAL
    loadPesan();
  </script>

</body>

</html>