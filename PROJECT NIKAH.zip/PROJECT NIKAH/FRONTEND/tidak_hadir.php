<?php 
include "../BACKEND/koneksi.php";

$data = mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE keterangan='Tidak Hadir'");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Tamu Tidak Hadir</title>
    <link rel="stylesheet" href="tidak_hadir.css">
</head>
<body>

<h2>Data Tamu Tidak Hadir</h2>
    <a href="dashboard.php" class="btn-kembali">← Kembali</a>
</div>

<table>
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Keterangan</th>
        <th>Ucapan</th>
    </tr>

<?php $no = 1; ?>
<?php while ($row = mysqli_fetch_assoc($data)) : ?>
<tr>
    <td><?= $no++; ?></td>
    <td><?= $row['nama']; ?></td>
    <td><?= $row['alamat']; ?></td>
    <td><?= $row['keterangan']; ?></td>
    <td><?= $row['ucapan']; ?></td>
</tr>
<?php endwhile; ?>
</table>

</body>
</html>