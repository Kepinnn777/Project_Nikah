<?php
include "../BACKEND/koneksi.php";

$total = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu"));
$hadir = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE keterangan='Hadir'"));
$tidak = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE keterangan='Tidak Hadir'"));

$data = mysqli_query($koneksi, "SELECT * FROM buku_tamu ORDER BY id_tamu DESC");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan</title>
    <link rel="stylesheet" href="admin.css">
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Laporan</h2>
        <img src="GAMBAR/" alt="">
        <ul>
            <li><a href="login.php">Admin</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li class="active">Laporan</li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main">
        <header>
            <h1>Laporan</h1>
        </header>

        <!-- Card Statistik -->
        <div class="cards">
            <div class="card">
            <a href="hadir.php">
            <h3><?= $hadir; ?></h3>
                <p>Tamu Yang Hadir</p>
            </a>
            </div>
            <div class="card">
            <a href="tidak_hadir.php">
            <h3><?= $tidak; ?></h3>
            <p>Tamu Tidak Hadir</p>
            </a>
        </div>
        </div>

        <!-- Table -->
        <div class="table-container">
            <h2>Data Tamu Yang Hadir</h2>
            <table>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Keterangan</th>
                    <th>Ucapan</th>
                </tr>
                
        <?php $no = 1; ?>
        <?php while ($row = mysqli_fetch_assoc($data)) : ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['nama']; ?></td>
            <td><?= $row['alamat']; ?></td>
            <td><?= $row['keterangan']; ?></td>
            <td><?= $row['ucapan']; ?></td>
        </tr>
        <?php endwhile; ?>
            </table>
        </div>
    </div>
</body>

</html>