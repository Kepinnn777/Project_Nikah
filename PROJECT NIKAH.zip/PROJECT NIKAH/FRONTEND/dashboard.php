<?php
include "../BACKEND/koneksi.php";

$total = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu"));
$hadir = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE keterangan='Hadir'"));
$tidak = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE keterangan='Tidak Hadir'"));

$data = mysqli_query($koneksi, "SELECT * FROM buku_tamu ORDER BY id_tamu DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="dashboard.css">
</head>

<body>

<div class="sidebar">
    <h2>Data Tamu</h2>
    <ul>
        <li class="active">Data Tamu</li>
        <li><a href="login.php">Admin</a></li>
    </ul>
</div>

<div class="main">
    <h1>Data Tamu</h1>

    <div class="cards">
        <div class="card">
            <h3><?= $total; ?></h3>
            <p>Jumlah Tamu</p>
        </div>
        <div class="card">
            <h3><?= $hadir; ?></h3>
            <p>Hadir</p>
        </div>
        <div class="card">
            <h3><?= $tidak; ?></h3>
            <p>Tidak Hadir</p>
        </div>
    </div>

    <button onclick="window.location.href='input_tamu.php'">+ Tambah Tamu</button>

    <table border="1" cellpadding="10">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Keterangan</th>
            <th>Ucapan</th>
        </tr>

        <?php $no = 1; ?>
        <?php while ($row = mysqli_fetch_assoc($data)) : ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['nama']; ?></td>
            <td><?= $row['alamat']; ?></td>
            <td><?= $row['keterangan']; ?></td>
            <td><?= $row['ucapan']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>