<?php include "../BACKEND/koneksi.php";

$data = mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE keterangan='Hadir'");
?>

<link rel="stylesheet" href="hadir.css">
<h2>Data Tamu Hadir</h2>

<a href="dashboard.php" class="btn-kembali">← Kembali</a>
<table border="1">
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Keterangan</th>
        <th>Ucapan</th>
    </tr>

<?php $no = 1; ?>
<?php while ($row = mysqli_fetch_assoc($data)) : ?>
<tr>
    <td><?= $no++; ?></td>
    <td><?= $row['nama']; ?></td>
    <td><?= $row['alamat']; ?></td>
    <td><?= $row['keterangan']; ?></td>
    <td><?= $row['ucapan']; ?></td>
</tr>
<?php endwhile; ?>
</table>