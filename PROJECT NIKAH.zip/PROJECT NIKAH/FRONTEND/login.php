<?php
include "../BACKEND/koneksi.php";

if (isset($_POST['btnSimpan'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password'];
    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE username='$username'");

    if (!$query) {
        die("Query error: " . mysqli_error($koneksi));
    }

    $data = mysqli_fetch_assoc($query);

    
    if ($data) {

        if ($password == $data['password']) {
            echo "<script>alert('Login berhasil'); window.location='admin.php';</script>";
            exit;
        } else {
            echo "<script>alert('Password salah');</script>";
        }

    } else {
        echo "<script>alert('Username tidak ditemukan');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>

<h1 align="center">LOGIN ADMIN</h1>

<form action="" method="post">
    <div class="row">
        <label>Username</label>
        <input type="text" name="username" required>
    </div>

    <div class="row">
        <label>Password</label>
        <input type="password" name="password" placeholder="Masukkan password" required>
    </div>

    <div class="row">
        <input type="submit" class="tombol" value="LOGIN" name="btnSimpan">
    </div>
</form>

</body>
</html>