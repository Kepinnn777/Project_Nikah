<?php
include "../BACKEND/koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>INPUT TAMU</title>
    <link rel="stylesheet" href="inputtamu.css">
</head>
<body>

<h1 align="center">INPUT TAMU</h1>

<form action="../BACKEND/simpan_tamu.php" method="post">
<div style="width:300px; margin:auto;">

    <label>Nama</label><br>
    <input type="text" name="nama" required><br><br>

    <label>Alamat</label><br>
    <textarea name="alamat" required></textarea><br><br>

    <label>Keterangan</label><br>
    <input type="radio" name="keterangan" value="Hadir" required> Hadir
    <input type="radio" name="keterangan" value="Tidak Hadir"> Tidak Hadir
    <br><br>

    <label>Ucapan</label><br>
    <textarea name="ucapan"></textarea><br><br>

    <input type="submit" name="btnSimpan" value="KIRIM">

</div>
</form>

</body>
</html>