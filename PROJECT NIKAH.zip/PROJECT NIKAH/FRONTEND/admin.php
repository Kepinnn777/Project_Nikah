<?php
include "../BACKEND/koneksi.php";

$total = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu"));
$hadir = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE keterangan='Hadir'"));
$tidak = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE keterangan='Tidak Hadir'"));

$data = mysqli_query($koneksi, "SELECT * FROM buku_tamu ORDER BY id_tamu DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="admin.css">
</head>

<body>

<div class="sidebar">
    <h2>Admin</h2>
    <ul>
        <li class="active">Dashboard</li>
        <li><a href="laporan.php">Laporan</a></li>
        <li onclick="logout()">Logout</li>
    </ul>
</div>

<div class="main">
    <header>
        <h1>Dashboard</h1>
    </header>

    <!-- Statistik -->
    <div class="cards">
        <div class="card">
            <h3><?= $total; ?></h3>
            <p>Jumlah Tamu</p>
        </div>
        <div class="card">
            <h3><?= $hadir; ?></h3>
            <p>Hadir</p>
        </div>
        <div class="card">
            <h3><?= $tidak; ?></h3>
            <p>Tidak Hadir</p>
        </div>
    </div>

    <!-- Tombol tambah -->
    <br>
    <button onclick="window.location.href='input_tamu.php'">+ Tambah Tamu</button>

    <!-- Tabel -->
    <div class="table-container">
        <h2>Data Tamu</h2>

        <table border="1" cellpadding="10">
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Keterangan</th>
        <th>Ucapan</th>
        <th>Aksi</th>
    </tr>

    <?php $no = 1; ?>
    <?php while ($row = mysqli_fetch_assoc($data)) : ?>
    <tr>
        <td><?= $no++; ?></td>
        <td><?= $row['nama']; ?></td>
        <td><?= $row['alamat']; ?></td>
        <td><?= $row['keterangan']; ?></td>
        <td><?= $row['ucapan']; ?></td>
        <td>
            <a href="../BACKEND/edit_tamu.php?id=<?= $row['id_tamu']; ?>">Edit</a> |
            <a href="../BACKEND/hapus_tamu.php?id=<?= $row['id_tamu']; ?>" onclick="return confirm('Yakin mau hapus?')">Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
    </div>
</div>

<script>
function logout() {
    alert("Logout berhasil!");
    window.location.href = "login.php";
}
</script>

</body>
</html>