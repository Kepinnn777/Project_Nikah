<?php
include "koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$keterangan = $_POST['keterangan'];
$ucapan = $_POST['ucapan'];

mysqli_query($koneksi, "UPDATE buku_tamu SET 
    nama='$nama',
    alamat='$alamat',
    keterangan='$keterangan',
    ucapan='$ucapan'
    WHERE id_tamu='$id'
");

header("Location: ../FRONTEND/dashboard.php");
exit;   