<?php
include "koneksi.php";

$id = $_GET['id'];

mysqli_query($koneksi, "DELETE FROM buku_tamu WHERE id_tamu='$id'");

header("Location: ../FRONTEND/dashboard.php");
exit;