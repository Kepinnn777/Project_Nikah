<?php
session_start();
session_unset();
session_destroy();

// arahkan ke dashboard (bukan login)
header("Location: dashboard.php");
exit;