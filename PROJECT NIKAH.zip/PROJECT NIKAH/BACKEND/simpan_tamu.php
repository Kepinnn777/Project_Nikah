<?php
include "koneksi.php";

$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$keterangan = $_POST['keterangan'];
$ucapan = $_POST['ucapan'];

mysqli_query($koneksi, "INSERT INTO buku_tamu (nama, alamat, keterangan, ucapan) 
VALUES ('$nama','$alamat','$keterangan','$ucapan')");

header("Location: ../FRONTEND/dashboard.php");
exit;