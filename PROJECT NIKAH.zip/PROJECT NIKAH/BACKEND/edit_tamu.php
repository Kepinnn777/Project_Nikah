<?php
include "../BACKEND/koneksi.php";

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM buku_tamu WHERE id_tamu='$id'");
$row = mysqli_fetch_assoc($data);
?>

<link rel="stylesheet" href="edit_tamu.css">
<div class="container">
<h2>Edit Tamu</h2>

<form action="../BACKEND/update_tamu.php" method="post">
    <input type="hidden" name="id" value="<?= $row['id_tamu']; ?>">

    Nama:<br>
    <input type="text" name="nama" value="<?= $row['nama']; ?>"><br>

    Alamat:<br>
    <input type="text" name="alamat" value="<?= $row['alamat']; ?>"><br>

    Keterangan:<br>
    <select name="keterangan">
        <option value="Hadir" <?= $row['keterangan']=='Hadir'?'selected':''; ?>>Hadir</option>
        <option value="Tidak Hadir" <?= $row['keterangan']=='Tidak Hadir'?'selected':''; ?>>Tidak Hadir</option>
    </select><br>

    Ucapan:<br>
    <textarea name="ucapan"><?= $row['ucapan']; ?></textarea><br><br>

    <button type="submit">Update</button>
</form>
</div>